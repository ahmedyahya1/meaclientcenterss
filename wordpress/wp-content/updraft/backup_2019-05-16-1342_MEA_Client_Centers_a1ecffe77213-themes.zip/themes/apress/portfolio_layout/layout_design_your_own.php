<?php 
include get_template_directory().'/framework/variables/variables-portfolio-layout.php';
//Portfolio Layout Style 3
?>

  <?php 
echo '<div class="portfolio_content_area">';
the_content();
echo '</div>';?>

