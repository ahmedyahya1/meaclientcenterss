 <?php global $apress_data, $woocommerce; ?>
    
    <?php $nofollow = ' rel="nofollow"'; ?>
  
    <div class="share-box">

    <h6><?php echo __('Share This', 'apress'); ?></h6>
    <?php apress_theme_social_sharing(); ?>
  </div>
          


          

  